var gulp = require('gulp');
var eslint = require('gulp-eslint');
var jasmine = require('gulp-jasmine');
var reporters = require('jasmine-reporters');
var fs = require('fs');
var exit = require('gulp-exit');

gulp.task('lint', async () => {
    return gulp.src(['**/*.js','!node_modules/**', '!gulpfile.js'])
        .pipe(eslint())
        .pipe(eslint.format())
        .pipe(eslint.format('html', fs.createWriteStream('lintReports/lint_report.html')))
        .pipe(eslint.format('checkstyle', fs.createWriteStream('lintReports/checkstyle.xml')))
        .pipe(eslint.failAfterError());
});
  
gulp.task('test', async function () {
  return gulp.src(['specs/*.js'])
 // gulp-jasmine works on filepaths so you can't have any plugins before it
    .pipe(jasmine({
       reporter: new reporters.JUnitXmlReporter({
         savePath: 'testReport/JUnit/'
      })}))
    .pipe(exit())
});



