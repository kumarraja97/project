const register = require('../src/model/userslogin');
const deleteBookingModel = require('../src/model/deleteBooking');
const packageModel = require('../src/model/packageModel');
const ViewBookModel = require('../src/model/viewBookings');
const packageService = require('../src/service/packageService');
const ViewBookService = require('../src/service/viewBookings');
const bookmodel = require('../src/model/booking');
const bookservice = require('../src/service/booking')
const regServ = require('../src/service/userslogin')
const errorlog = require('../src/utilities/ErrorLogger');
const request = require('request');
const hotdealurl = "http://localhost:4000/package/hotDeals";

describe('testcase2', function() {
    // it('check register-T',function(done){
    //     let users={
    //         "name": "ghyj",
    //         "emailId": "abc@gmail.com",
    //         "contactNo": 9090990832,
    //         "password": "@1234",
    //     }
    //     register.register(users).then((data)=>{expect(data).toBeDefined();done();})
    // })
    it('check register-T', function(done){
        let users={
            "name": "kllkf",
            "emailId": "olllef@gmail.com",
            "contactNo": 6234567009,
            "password": "kklf@1234",
        }
         regServ.register(users).then((data)=>{done();expect(data).toBeDefined();})
    })
})

    describe('UserStory-7', function() {
        it('delete Booking-T',  function(done) {
              deleteBookingModel.deleteBooking("B1003").then((data)=>{done();expect(data).toBe("B1003");})
            
        })

    })
    describe('UserStory-4', function() {
        it('Packages-search-continent-T',  function(done) {
              packageModel.getDestination("Australia").then((data)=>{done();expect(data[0].name).toMatch("Grand Tour of Australia");})
            
        })
        it('Packages-search-tourHighlights-T',  function(done) {
              packageModel.getDestination("Rome").then((data)=>{done();expect(data[0].continent).toMatch("Europe");})
        })
        it('Packages-search-tourHighlights-T',  function(done) {
              packageModel.getDestination("Meiji Shrine, Mount Fuji").then((data)=>{done();expect(data[0].continent).toMatch("Asia");})
            
        })
        it('Packages-search-unavailableDestination-F',  function(done) {
            packageService.getDestination("Mysore").catch ((error)=>{
                expect(error).toMatch("Sorry we don't operate in this Destination");
                done();
            })
        })
        it('PlannedTrips-search-unavailableDestination-F', function(done){
            packageService.getDestination("India").catch(err=>{
                expect(err.status).toBe(404)
                done();
            })

        })


    })
    describe('UserStory-6', function() {
        it('PlannedTrips-T1',  function(done) {
              ViewBookModel.viewBookings("U1001").then((data)=>{done();expect(data[0].destinationName).toEqual('A Week in Greece: Athens, Mykonos & Santorini');})
            
        })
        it('PlannedTrips-T2',  function(done) {
              ViewBookModel.viewBookings("U1001").then((data)=>{done();expect(data[1].destinationName).toMatch("Romantic Europe: Paris, Venice & Vienna");})
            
        })
        it('PlannedTrips-T3',  function(done){
              ViewBookModel.viewBookings("U1002").then((data)=>{done();expect(data[0].bookingId).toMatch("B1003");})
            
        })
        it('PlannedTrips-UnavailableUserData-F1',  function(done) {
            ViewBookService.getBookingData("U1043").then((data)=>{})
            .catch( (error) =>{
                expect(error).toMatch("Sorry You have not planned any trips with us yet!");
                done();
            })
        })
        it('PlannedTrips-UnavailableUserData-F2', function(done){
            ViewBookService.getBookingData("U1056").catch(err=>{
                expect(err.status).toBe(404)
                done();
            })
        })
})
//--------->login
describe('TestCase-1-Login',()=>{
    // it('checking User Id-T', function(done){
    //     register.generateUserId().then((userid)=>{expect(userid).toBe('U1003');done()}) 
    // })
    // it('checking User Id-F', function(done){
    //     register.generateUserId().then((userid)=>{expect(userid).toBe('U1007');done()})
        
    // })
    it('checking Password-T', function(done){
        register.getPassword(9098765432).then((password)=>{done();expect(password).toMatch(/[A-Za-z0-9]+[!,@,#,$,%,^,&,*]/);})
        
    })
    // it('checking Password-F', function(done){
    //     register.getPassword(9098765672).then((password)=>{expect(password).toMatch(/[A-Za-z0-9]+[!,@,#,$,%,^,&,*]/);done()})
        
    // })
    it('checking logged user-T', function(done){
        regServ.login(9098765432,"Abc@1234").then((loggeddetails)=>{done();expect(loggeddetails).toBeDefined()})
        
    })
    // it('checking logged user-F', function(done){
    //     regServ.login(9447654835,"cbd@1234").then((loggeddetails)=>{expect(loggeddetails).toBeDefined();done()})
    // })
 })

//------------>hotdeals
 describe('TestCase-3-Hotdeals', function() {
    it('checking model  HotDeal-T',  function(done) {
          packageModel.getHotdeal().then((data)=>{done();expect(data).toBeDefined();})
       
    })
    it('route 1-T', function (done) {
        request.get(hotdealurl, function (error, response, body) {
            done();
            expect(response.statusCode).toBe(200);
            
        })
    })
    it('checking regServ HotDeal-T',  function(done) {
          packageService.getHotdeals().then((data)=>{done();expect(data).toBeDefined();})
        
    })
 })

//------------>booking
describe('TestCase-5-Booking', () => {
    // it('check Booking-T',  function(done){
    //     let input = { userId: "U1001", destId: "D1001", destinationName: "A Week in Greece: Athens, Mykonos & Santorini", checkInDate: "2018-12-09", checkOutDate: "2018-12-16", noOfPersons: 2, totalCharges: 5998 }
    //     bookservice.bookTrip(input).then((data)=>{done();expect(data).toBeDefined();})
        
    // })
    it('check Route-T', function (done) {
        let input = { userId: "U1001", destId: "D1001", destinationName: "A Week in Greece: Athens, Mykonos & Santorini", checkInDate: "2018-12-09", checkOutDate: "2018-12-16", noOfPersons: 2, totalCharges: 5998 }
        bookservice.bookTrip(input).then((data) => {
            done();
            expect(data).toBeTruthy();
            console.log('route 1 passed');
        }).catch(err => {
                done();
                expect(err).toBeTruthy();
                console.log('route 2 passed');
            })
    })
    // it('checking Book Id-T',  function(done) {
    //     bookmodel.generateBookingId().then((bookid)=>{ expect(bookid).toBe('B1004');done()})
    // })

})


