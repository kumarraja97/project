let db = require('../model/booking');

booking={};


booking.bookTrip=(bookObj)=>{
    return db.book(bookObj).then((result)=>{
        if(result===null){
            let err = new Error("Booking not successfull");
            err.status = 404;
            throw err;
        }else{
            return result
        }
    })
    
}


module.exports=booking;