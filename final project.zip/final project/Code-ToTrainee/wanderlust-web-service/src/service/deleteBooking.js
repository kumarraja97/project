const db = require('../model/deleteBooking');
const DelService = {}

DelService.deleteBooking = (bookingId) => {
    return db.deleteBooking(bookingId).then(bid => {
        if (bid === null) {
            let err = new Error("Could Not cancel the booking");
            err.status = 500;
            throw err;
        } else {
            return bid;
        }
    })
}
module.exports = DelService