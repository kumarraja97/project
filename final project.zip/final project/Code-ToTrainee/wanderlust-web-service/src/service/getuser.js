const usersdeatilsdb = require('../model/getuser');

let getuserservice={}

getuserservice.getuser=(users)=>{
    return usersdeatilsdb.getuserdb(users).then(data=>{
        if(data==null){
            let err = new Error(" Registration failed! Please try again");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

getuserservice.deleteuser=(users)=>{
    return usersdeatilsdb.deleteuserdb(users).then(data=>{
        if(data==null){
            let err = new Error(" Registration failed! Please try again");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

module.exports = getuserservice
