let packagesdb=require("../model/packageModel")
let wpackageService={}
wpackageService.getDestination = (continent) => {
    return packagesdb.getDestination(continent).then((bookings) => {
        if (bookings === null) {
            let err = new Error("Sorry we don't operate in this Destination");
            err.status = 404;
            throw err;
        } else {
            return bookings;
        }
    })
}
wpackageService.getHotdeals = () => {
    return packagesdb.getHotdeal().then((bookings) => {
        if (bookings === null) {
            let err = new Error("No Hotdeals is found");
            err.status = 404;
            throw err;
        } else {
            return bookings;
            }
        
    })
}

wpackageService.getAllDestination = () => {
    return packagesdb.getAllDestinationdb().then((bookings) => {
        if (bookings.length<=0) {
            let err = new Error("No Hotdeals is found");
            err.status = 404;
            throw err;
        } else {
            return bookings;
            }
    })
}


wpackageService.getDestinationById = (destinationId) => {
    return packagesdb.getDestinationById(destinationId).then((bookings) => {
        if (bookings === null) {
            let err = new Error("Sorry Destination not Found");
            err.status = 404;
            throw err;
        } else {
            return bookings;
        }
    })
}
module.exports = wpackageService;