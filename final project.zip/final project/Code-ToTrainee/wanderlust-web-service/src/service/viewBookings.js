const db = require('../model/viewBookings');


bookingData={};


bookingData.getBookingData=(custId)=>{
    return db.viewBookings(custId).then((result)=>{
        if(result){
            return result
        }
        else{
            let err = new Error("Sorry You have not planned any trips with us yet!");
            err.status = 404;
            throw err;
        }
    })
}


module.exports=bookingData;