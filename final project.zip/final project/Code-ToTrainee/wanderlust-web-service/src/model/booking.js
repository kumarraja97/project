let connection = require("../utilities/connections")

let bookingDb = {}


bookingDb.generateBookingId = () => {
    return connection.getBookingCollection().then((collection) => {

        return collection.distinct("bookingId").then((ids) => {
            let arr = []
            ids.forEach(data => {
                arr.push(data.substr(1))
            });
            let uId = Math.max(...arr);
            let newId = uId + 1;
            return "B" + newId;
        })
    })
}

bookingDb.book = (bookObj) => {
    return connection.getBookingCollection().then((data) => {
        // console.log(data)
        return bookingDb.generateBookingId().then((result) => {
            bookObj.bookingId = result;
            let time = new Date();
            let timeStamp = time.getTime();
            bookObj.timeStamp = timeStamp;
            bookObj.destId = bookObj.destinationId;

            return data.insertMany([bookObj]).then((result1) => {
                if (result1) {
                    connection.getUserCollection().then((users) => {
                        users.updateOne({ "userId": bookObj.userId }, { $push: { bookings: bookObj.bookingId } }).then((success) => {
                            if (success.nModified === 1) {
                                connection.getUserDestination().then((destinations) => {
                                    destinations.findOne({ "destinationId": bookObj.destId }).then((found) => {
                                        if (found) {
                                            destinations.updateOne({ "destinationId": bookObj.destId }, { $inc: { availability: -bookObj.noOfPersons } }).then((done) => {
                                                if (done.nModified === 1) {

                                                    destinations.findOne({ "destinationId": bookObj.destId }).then((abc)=>{
                                                        console.log(abc.availability)
                                                    })
                                                }
                                            })
                                        } else {
                                            connection.getUserHotdeal().then((hotdeals) => {
                                                hotdeals.findOne({ "destinationId": bookObj.destId }).then((deals) => {
                                                    if (deals) {
                                                        hotdeals.updateOne({ "destinationId": bookObj.destId }, { $inc: { availability: -bookObj.noOfPersons } }).then((done1) => {
                                                            console.log("hot deals updated")
                                                        })
                                                    }
                                                })
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    })
                    return result1[0]
                } else {
                    return null;
                }
            })
        })
    })
}


module.exports = bookingDb;




