const userDetails = require('./beanClasses/users');
const connection = require("../utilities/connections")
bookingdb = {};
bookingdb.deleteBooking = (bkId) => {
    return connection.getBookingCollection().then((data) => {
        return data.findOne({ "bookingId": bkId }).then((bkngdata) => {
            let noOfPersons = bkngdata.noOfPersons;
            let destId = bkngdata.destId;
            let bookid = bkngdata.bookingId;
            let userId=bkngdata.userId;
            if(destId.match(/^D/)){
                return connection.getUserDestination().then((destData) => {
                    return destData.findOne({ "destinationId": destId }).then((SelectedData) => {
                        return destData.updateOne({ destinationId: destId }, { $inc: { availability: noOfPersons } }).then((updateStatus) => {
                            if (updateStatus.nModified === 1) {
                                return data.deleteOne({ "bookingId": bkId }).then((delData) => {
                                    console.log(delData)
                                    if (delData.deletedCount === 1) {
                                        connection.getUserCollection().then(userdatas => {
                                            userdatas.updateOne({"userId":userId},{$pull:{bookings:bookid}}).then((result)=>{
                                                
                                            })
                                       })
                                       return bkId;
                                    }else{
                                        return null;
                                    }
    
                                })
                            }
                        })
                    })
                })
        }else{
            return connection.getUserHotdeal().then((destData) => {
                return destData.findOne({ "destinationId": destId }).then((SelectedData) => {
                    return destData.updateOne({ destinationId: destId }, { $inc: { availability: noOfPersons } }).then((updateStatus) => {
                        if (updateStatus.nModified === 1) {
                            return data.deleteOne({ "bookingId": bkId }).then((delData) => {
                                if (delData.deletedCount === 1) {
                                     connection.getUserCollection().then(userdatas => {
                                         userdatas.updateOne({"userId":userId},{$pull:{bookings:bookid}}).then((result)=>{
                                             
                                         })
                                    })
                                    return bkId;
                                }else{
                                    return null;
                                }
                            })
                        }
                    })
                })
            })
        }

        })
    })
}






// bookingdb.deleteBooking("B1007")

module.exports = bookingdb;



