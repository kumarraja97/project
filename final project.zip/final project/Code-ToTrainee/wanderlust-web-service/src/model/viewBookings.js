const dbModel = require('../utilities/connections');


bookingDb = {};

bookingDb.viewBookings =(userId)=>{
    return dbModel.getBookingCollection().then((data)=>{
        return data.find({"userId":userId},{_id:0}).then((data)=>{
            if(data.length>0){
                return data;
            }else{
                return null;
            }
        })
    })
}

module.exports=bookingDb;

