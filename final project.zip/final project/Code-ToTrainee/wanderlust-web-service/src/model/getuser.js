const connection = require("../utilities/connections")

const usersdeatilsdb = {}

usersdeatilsdb.getuserdb = (userid) => {
    return connection.getUserCollection().then((collection) => {
        return collection.findOne({ "userId": userid }).then((custinfo) => {
            if (custinfo) {
                console.log(custinfo)
                return custinfo;
            }
            else return null;
        })
    })
}

usersdeatilsdb.deleteuserdb = (userid) => {
    return connection.getUserCollection().then((collection) => {
        return collection.deleteOne({ "userId": userid }).then((custinfo) => {
            if (custinfo) {
                console.log(userid)
                return userid;
            }
            else return null;
        })
    })
}

module.exports = usersdeatilsdb;