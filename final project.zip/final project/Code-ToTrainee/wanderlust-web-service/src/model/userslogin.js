const userDetails = require( './beanClasses/users' );
const connection = require( "../utilities/connections" )

const usersDB = {}

usersDB.checkUser = ( contactNo ) => {
    return connection.getUserCollection().then( ( collection ) => {
        return collection.findOne( { "contactNo": contactNo } ).then( ( customerContact ) => {
            if( customerContact ) {
                return new userDetails( customerContact );
            }
            else return null;
        } )
    } )
}

usersDB.getPassword = ( contactNo ) => {
    return connection.getUserCollection().then( ( collection ) => {
        
        return collection.find( { "contactNo": contactNo }, { _id: 0, password: 1 } ).then( ( password ) => {
            if( password.length != 0 ){


                


                return password[0].password;
            }
            else 
                return null;
        } )
    } )
}

usersDB.generateUserId = () => {
    return connection.getUserCollection().then( ( collection ) => {
        return collection.distinct( "userId" ).then( ( ids ) => {
            let arr = []
            ids.forEach( data => {
                arr.push( data.substr( 1 ) )
            } );
            let uId = Math.max( ...arr );
            let newId = uId + 1;
            return"U" + newId;
        } )
    } )
}

usersDB.generateBookingId = () => {
    return connection.getUserCollection().then( ( collection ) => {
        return collection.distinct( "bookings" ).then( ( ids ) => {
            let arr = []
            ids.forEach( data => {
                arr.push( data.substr( 1 ) )
            } );
            let uId = Math.max( ...arr );
            let newId = uId + 1;
            return"B" + newId;
        } )
    } )
}


usersDB.register = ( users ) => {
    return connection.getUserCollection().then( ( collection ) => {
        return usersDB.generateUserId().then( data => {
            users.userId = data;
            users.bookings = [];
            return collection.findOne( { "contactNo": users.contactNo } ).then( ( contactno ) => {
                if( !contactno ) {
                    return collection.insertMany( users ).then( update => {
                        if( update.length > 0 ) {
                            return data;
                        }
                    } )

                } else{
                    return null;
                }

            } )
        } )
    } )
}




module.exports = usersDB;
