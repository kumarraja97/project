const express = require('express');
const router = express.Router();
// const setupBooking=require('../model/setupBooking')
const DelService = require('../service/deleteBooking')
const Booking = require('../model/beanClasses/booking')

const bookingService = require('../service/booking')
const packageService = require('../service/packageService')



//router to deleteBooking
router.delete('/cancelBooking/:bookingId', (req, res, next) => {
    let bookingId = req.params.bookingId;
    DelService.deleteBooking(bookingId).then(bId => {
        res.json({ "message": "Successfully deleted the booking with Id: " + bId})
    }).catch((err) => next(err))
})


// booking

router.post('/:userId/:destinationId', (req, res, next) => {
    const booking = new Booking(req.body);
    let userId = req.params.userId;
    let destId = req.params.destinationId;
    booking.destinationId = destId;
    booking.userId = userId;
    console.log(booking)
    bookingService.bookTrip(booking).then((bookObj) => {
        res.json({ "message": "Congratulations! Trip planned to " + bookObj.destinationName  })
    }).catch((err) => { next(err) })
})

router.post('/subscribe', (req, res, next) => {
    const emaild =req.body;
    subscribeservice.subscribe(emaild).then((bookObj) => {
        res.json({ "message": "subscribed"})
    }).catch((err) => { next(err) })
})

// get destination details

router.get('/getDetails/:destinationId', (req, res, next) => {
    let destId = req.params.destinationId
    packageService.getDestinationById(destId).then(array => {
        res.json(array)
    }).catch((err) => next(err))
})


module.exports = router;