const express = require('express');
const router = express.Router();
const setupUser = require("../model/setupUser")
const userservice = require('../service/userslogin')

const viewservice=require('../service/viewBookings')
const users=require('../model/beanClasses/users')
const delservice=require('../service/deleteBooking')
const getuserservice=require('../service/getuser')




router.get("/setup", (req, res, next) => {
    setupUser.userSetup().then((data) => {
        res.send(data)
    }).catch(err => next(err));
})




//router to login
router.post('/login', function (req, res, next) {
    let contactNo = req.body.contactNo;
    let password = req.body.password;
    userservice.login(parseInt(contactNo), password).then(function (userDetails) {
        res.send(userDetails);
    }).catch(err => next(err));
})

router.get('/getBookings/:userId', function(req,res,next){
    let userId=req.params.userId;
    viewservice.getBookingData(userId).then((bookings)=>{
        res.json(bookings)
    }).catch(err=>next(err))
})

//router to register
router.post('/register', function (req, res, next) {
    const data=new users(req.body)
    console.log(data)
    userservice.register(data).then(registerDetails=> {
        if(registerDetails){
        res.json({ "message": "Registration is successful with User Id : " +registerDetails });
        }
    }).catch(err => next(err));
})

//route for get user
router.get('/getuser/:userId', function(req,res,next){
    let userId=req.params.userId;
    getuserservice.getuser(userId).then((bookings)=>{
        res.json(bookings)
    }).catch(err=>next(err))
})


module.exports = router;

