import React, { Component } from "react";
import axios from "axios";
import { backendUrlUser } from '../BackendURL';
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import "../index.css";


class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            registerform: {
                name: "",
                emailId: "",
                contactNo: "",
                password: ""
            },
            registerformErrorMessage: {
                name: "",
                emailId: "",
                contactNo: "",
                password: ""
            },
            registerformValid: {
                name: false,
                emailId: false,
                contactNo: false,
                password: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: "",
            done:false
            // loadHome: false,
            // loadRegister: false,
            // userId: ""
        }
    }
    register = () => {
        const { registerform } = this.state;
        this.setState({ successMessage: "", errorMessage: "" });
        axios.post(backendUrlUser+'/register', registerform)
            // .then(response => {
            //     console.log(response);
            // let userId = response.data.userId;
            // sessionStorage.setItem("contactNo", response.data.contactNo);
            // sessionStorage.setItem("userId", userId);
            // sessionStorage.setItem("userName", response.data.name);;
            // window.location.reload();
            // this.setState({ loadHome: true, userId: userId })
            .then(response => { this.setState({ successMessage: response.data.message,done:true, errorMessage: "" }) })
            .catch(error => { this.setState({ errorMessage: error.response.data.message,done:false, successMessage: "" }) })


        // }).catch(error => {
        //     console.log(error);
        //     this.errorMessage = error.message;
        //     // sessionStorage.clear();
        // })
        // console.log(this.state.loginform.contactNo, this.state.loginform.password);
    }


    handleSubmit = (event) => {
        event.preventDefault();
        this.register();
    }
    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { registerform } = this.state;
        this.setState({
            registerform: { ...registerform, [name]: value }
        });
        this.validateField(name, value);
        // console.log(this.state.loginform[name], name);
    }
    validateField = (fieldName, value) => {
        let fieldValidationErrors = this.state.registerformErrorMessage;
        let formValid = this.state.registerformValid;
        switch (fieldName) {
            case "name":
                let nameRegex = /^[A-z][A-z ]*[A-z]$/
                if (!value || value === "") {
                    fieldValidationErrors.name = "Please enter your Name";
                    formValid.name = false;
                } else if (!value.match(nameRegex)) {
                    fieldValidationErrors.name = "Invalid Name";
                    formValid.name = false;
                } else {
                    fieldValidationErrors.name = "";
                    formValid.name = true;
                }
                break;
            case "emailId":
                let emailIdRegex = /^[A-z0-9_]+@[A-z]+.[A-z]{2,3}$/;
                if (!value || value === "") {
                    fieldValidationErrors.emailId = "Please enter your Email Id";
                    formValid.emailId = false;
                } else if (!value.match(emailIdRegex)) {
                    fieldValidationErrors.emailId = "Invalid Email Id";
                    formValid.emailId = false;
                } else {
                    fieldValidationErrors.emailId = "";
                    formValid.emailId = true;
                }
                break;
            case "contactNo":
                let cnoRegex = /^[1-9]\d{9}$/
                if (!value || value === "") {
                    fieldValidationErrors.contactNo = "Please enter your contact Number";
                    formValid.contactNo = false;
                } else if (!value.match(cnoRegex)) {
                    fieldValidationErrors.contactNo = "Invalid Contact Number";
                    formValid.contactNo = false;
                } else {
                    fieldValidationErrors.contactNo = "";
                    formValid.contactNo = true;
                }
                break;
            case "password":
                if (!value || value === "") {
                    fieldValidationErrors.password = "Password is mandatory";
                    formValid.password = false;
                    // } else if (!(value.match(/[a-zA-z]/) && value.match(/[0-9]/) && value.match([/_/]))) {
                } else if (!(value.length >= 7 && value.length <= 20) || !(value.match(/[A-Za-z0-9]+[!,@,#,$,%,^,&,*]/))) {
                    fieldValidationErrors.password = "Please Enter a valid password"
                    formValid.password = false;
                } else {
                    fieldValidationErrors.password = "";
                    formValid.password = true;
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.name && formValid.emailId && formValid.contactNo && formValid.password;
        this.setState({
            loginformErrorMessage: fieldValidationErrors,
            loginformValid: formValid,
            successMessage: ""
        });
    }

    render() {
        return (
            <div>
                <section id="registerPage" className="registerSection">    {/* *ngIf="!registerPage"  */}
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-4 offset-4 ">
                                {(this.state.done)?(<div>
                                    <h4 className="text-success text-center">Successfully Registered!</h4>
                                    <br/>
                                    <Link to="/login"><h4 className="text-primary text-center"> Click here to login</h4></Link>
                                    </div>):
                                    (<div>
                                <h1 className="text-left">Join Us</h1>
                                <form className="form text-left" onSubmit={this.handleSubmit}> {/* [formGroup]="loginForm" (ngSubmit)="login()" */}
                                    <div className="form-group">
                                        <label htmlFor="name">Name<span className="text-danger">*</span></label>
                                        <input
                                            type="text"
                                            value={this.state.registerform.name}
                                            onChange={this.handleChange}
                                            id="name"
                                            name="name"
                                            className="form-control inputline"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.name ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.name}
                                    </span>)
                                        : null}
                                    <div className="form-group">
                                        <label htmlFor="emailId">Email Id<span className="text-danger">*</span></label>
                                        <input
                                            type="email"
                                            value={this.state.registerform.emailId}
                                            onChange={this.handleChange}
                                            id="emailId"
                                            name="emailId"
                                            className="form-control inputline"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.emailId ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.emailId}
                                    </span>)
                                        : null}
                                    <div className="form-group">
                                        <label htmlFor="contactNo">Contact Number<span className="text-danger">*</span></label>
                                        <input
                                            type="number"
                                            value={this.state.registerform.contactNo}
                                            onChange={this.handleChange}
                                            id="contactNo"
                                            name="contactNo"
                                            className="form-control inputline"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.contactNo ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.contactNo}
                                    </span>)
                                        : null}
                                    <div className="form-group">
                                        <label htmlFor="password">Password<span className="text-danger">*</span></label>
                                        <input
                                            type="password"
                                            value={this.state.registerform.password}
                                            onChange={this.handleChange}
                                            id="password"
                                            name="password"
                                            className="form-control inputline"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.password ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.password}
                                    </span>)
                                        : null}<br />
                                    <span><span className="text-danger">*</span> marked feilds are mandatory</span>
                                    <br />
                                    <br/>
                                    <button
                                        type="submit"
                                        disabled={!this.state.registerformValid.buttonActive}
                                        className="btn btn-primary btn-lg btn-block"
                                    >
                                        Register
                                    </button>
                                    <span className="text-danger">{this.state.ErrorMessage}</span>
                                </form>
                                <br/>
                                </div>)}

                            </div>
                        </div>
                    </div>
                </section>
            </div>
        );
    }
}

export default Register;