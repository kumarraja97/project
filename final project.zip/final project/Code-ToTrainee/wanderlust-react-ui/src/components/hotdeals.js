import React, { Component } from "react";
import axios from "axios";
import { backendUrlPackage } from '../BackendURL';
import "bootstrap/dist/css/bootstrap.css";
import "../index.css";
import { ProgressSpinner } from 'primereact/progressspinner';
import { Sidebar } from 'primereact/sidebar';
import { TabView, TabPanel } from 'primereact/tabview';
import { InputSwitch } from 'primereact/inputswitch';
import { Redirect } from 'react-router-dom';
import Booking from './booking';
import {Link} from "react-router-dom";
import {ScrollPanel} from 'primereact/scrollpanel';
import Login from '../components/login';


class HotDeals extends Component {
    constructor(props) {
        super(props);
        this.state = {
            bookingForm: {
                noOfPersons: 1,
                date: "",
                flights: true,
            },
            bookingFormErrorMessage: {
                noOfPersons: "",
                date: ""
            },
            bookingFormValid: {
                noOfPersons: true,
                date: false,
                buttonActive: false
            },
            hotDeals: [],
            errorMessage: "",
            loadBook: false,
            showItinerary: false,
            index: "",
            show: true,
            deal: "",
            checkOutDate: new Date(),
            totalCharges: "",
            retologin:false
        }
    }

    displayPackageInclusions = () => {
        const packageInclusions = this.state.deal.details.itinerary.packageInclusions;
        if (this.state.deal) {
            return packageInclusions.map((pack, index) => (<li key={index}>{pack}</li>))
        }
        else {
            return null;
        }
    }

    displayPackageHighlights = () => {
        let packageHighLightsArray = [];
        let firstElement = (
            <div key={0}>
                {/* <h3>Day Wise itinerary</h3> */}
                <h5>Day 1</h5>
                {this.state.deal ? <div>{this.state.deal.details.itinerary.dayWiseDetails.firstDay}</div> : null}
            </div>
        );
        packageHighLightsArray.push(firstElement);
        if (this.state.deal) {
            this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.map((packageHighlight, index) => {
                let element = (
                    <div key={index + 1}>
                        <h5>Day {this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.indexOf(packageHighlight) + 2}</h5>
                        <div>{packageHighlight}</div>
                    </div>
                );
                return packageHighLightsArray.push(element)
            });
            let lastElement = (
                <div key={666}>
                    <h5>Day {this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.length + 2}</h5>
                    {this.state.deal.details.itinerary.dayWiseDetails.lastDay}
                    <div className="text-danger">
                        **This itinerary is just a suggestion, itinerary can be modified as per requirement. <Link
                           to="/contact">Contact us</Link> for more details.
                        </div>
                </div>
            );
            packageHighLightsArray.push(lastElement);
            return packageHighLightsArray;
        } else {
            return null;
        }
    }
    getHotDeals = () => {
        axios.get(backendUrlPackage + '/hotDeals')
            .then(response => {
                this.setState({ hotDeals: response.data, errorMessage: null, show: false })
            }).catch(error => {
                this.setState({ errorMessage: error.message, hotDeals: null })
            })
    }
    handleChange = (event) => {
        const target = event.target;
        const name = target.name;
        if (target.checked) {
            var value = target.checked;
        } else {
            value = target.value;
        }
        const { bookingForm } = this.state;
        this.setState({
            bookingForm: { ...bookingForm, [name]: value }
        });

        this.validateField(name, value);

    }

    validateField = (fieldname, value) => {
        let fieldValidationErrors = this.state.bookingFormErrorMessage;
        let formValid = this.state.bookingFormValid;
        switch (fieldname) {
            case "noOfPersons":
                if (value === "") {
                    fieldValidationErrors.noOfPersons = "This field can't be empty!";
                    formValid.noOfPersons = false;
                } else if (value < 1) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be less than 1!";
                    formValid.noOfPersons = false;
                } else if (value > 5) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be more than 5.";
                    formValid.noOfPersons = false;
                } else {
                    fieldValidationErrors.noOfPersons = "";
                    formValid.noOfPersons = true;
                }
                break;
            case "date":
                if (value === "") {
                    fieldValidationErrors.date = "This field can't be empty!";
                    formValid.date = false;
                } else {
                    let checkInDate = new Date(value);
                    let today = new Date();
                    if (today.getTime() > checkInDate.getTime()) {
                        fieldValidationErrors.date = "Check-in date cannot be a past date!";
                        formValid.date = false;
                    } else {
                        fieldValidationErrors.date = "";
                        formValid.date = true;
                    }
                }
                break;
            default:
                break;
        }

        formValid.buttonActive = formValid.noOfPersons && formValid.date;
        this.setState({
            loginformErrorMessage: fieldValidationErrors,
            loginformValid: formValid,
            successMessage: "",
            totalCharges: ""

        });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.calculateCharges();
    }
    calculateCharges = () => {
        this.setState({ totalCharges: 0 });
        let oneDay = 24 * 60 * 60 * 1000;
        let checkInDate = new Date(this.state.bookingForm.date);
        let checkOutDateinMs = Math.round(Math.abs((checkInDate.getTime() + (this.state.deal.noOfNights) * oneDay)));
        let finalCheckOutDate = new Date(checkOutDateinMs);
        this.setState({ checkOutDate: finalCheckOutDate.toDateString() });
        if (this.state.bookingForm.flights) {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.deal.chargesPerPerson + this.state.deal.flightCharges;
            this.setState({ totalCharges: totalCost });
        } else {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.deal.chargesPerPerson;
            this.setState({ totalCharges: totalCost});
        }
    }


    getitinerary = (hotDeal) => {
        this.setState({ index: 0, deal: hotDeal, showItinerary: true });

    }

    openBooking = (selectedPackage) => {
        this.setState({ index: 2, deal: selectedPackage, showItinerary: true })

        // console.log(this.state.deal)
    }

    loadBookingPage = (dealId) => {
        console.log(dealId)
        console.log(":here");
        this.setState({ visibleRight: false });
        sessionStorage.setItem('noOfPersons', this.state.bookingForm.noOfPersons);
        sessionStorage.setItem('checkInDate', this.state.bookingForm.date);
        sessionStorage.setItem('flight', this.state.bookingForm.flights);
        sessionStorage.setItem('dealId', dealId);
        this.setState({ show: true, bookingPage: true, showItinerary: false, dealId: dealId })
    }

    displayHotDeals = () => {
        let hotDealsArray = [];
        for (let hotDeal of this.state.hotDeals) {
            let name = hotDeal.imageUrl.split("/")[2]
            let element = (
                <div className="card bg-light text-dark package-card" key={hotDeal.destinationId}>
                    <div className="card-body row">
                        <div className="col-md-4">
                            <div className="image">
                                <img className="package-image" src={require("../../public/assets/" + name)} alt="" />
                            </div>
                        </div>
                        <div className="col-md-5">
                            <div className="featured-text text-center card-border text-lg-left ">
                                <h4>{hotDeal.name}</h4>
                                <div className="badge badge-info">{hotDeal.noOfNights}<em> Nights</em></div><br />
                                <span className="discount text-danger">{hotDeal.discount}% Instant Discount</span>
                                <p className="text-dark mb-0">{hotDeal.details.about}</p>
                            </div>
                            <br />

                        </div>
                        <div className="col-md-3">
                            <h4>Prices Starting From:</h4>
                            <div className="text-center text-success"><h6>${String(hotDeal.chargesPerPerson)[0]},{String(hotDeal.chargesPerPerson).substring(1)}.00</h6></div><br /><br />
                            <div><button className="btn btn-primary btn-block book" onClick={() => { this.getitinerary(hotDeal) }}>View Details</button></div><br />
                            <div><button className="btn btn-primary btn-block book" onClick={() => { this.openBooking(hotDeal) }}>Book </button>  </div>
                        </div>
                    </div>
                </div>

            );
            hotDealsArray.push(element);
        }
        return hotDealsArray;
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        this.getHotDeals();
    }
    render() {
        return (
            <div>
                 {this.state.retologin? <Redirect to={"/login"} Component={Login}></Redirect>:null}
                {this.state.show ? (
                    <div id="details" className="details-section">
                        <div className="text-center">
                            <ProgressSpinner></ProgressSpinner>
                        </div>
                    </div>) :
                    <div>
                        {this.state.booking ? (<Redirect to={{ pathname: "/book/" + this.state.deal.destinationId, state: { noOfPersons: this.state.bookingForm.noOfPersons, date: this.state.bookingForm.date, flights: this.state.bookingForm.flights } }} component={Booking}></Redirect>) : null}
                        <div>
                            {/* <!-- hot deals normal list display --> */}
                            <div className="row destination card">  {/* *ngIf="!bookingPage" */}
                                {this.displayHotDeals()}
                                <Sidebar visible={this.state.showItinerary}  baseZIndex={"1"} position="right" className="p-sidebar-lg" onHide={(e) => this.setState({ showItinerary: false })}>
                                    <h2>{this.state.deal.name}</h2>
                                    <ScrollPanel style={{width: '100%', height: '500px'}}>
                                    <TabView activeIndex={Number(this.state.index)} onTabChange={(e) => this.setState({ index: e.index })}>
                                        <TabPanel header="Overview">
                                            <div className="row">
                                                {this.state.deal ?
                                                    <div className="col-md-6 text-center">
                                                        <img className="package-image" src={require("../../public/assets/" + this.state.deal.imageUrl.split("/")[2])} alt="destination comes here" />
                                                    </div> : null}
                                                <div className="col-md-6 text-left">
                                                    <h4>Package Includes:</h4>
                                                    <ul>
                                                        {this.state.showItinerary ? this.displayPackageInclusions() : null}
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="text-justify itineraryAbout">
                                                <h4>Tour Overview:</h4>
                                                {this.state.deal ? this.state.deal.details.about : null}
                                            </div>
                                        </TabPanel>
                                        <TabPanel header="Itinerary" >
                                            <div className="text-left">{this.displayPackageHighlights()}</div>
                                        </TabPanel>
                                        <TabPanel header="Book">
                                            <h4 className="itenaryAbout text-left">**Charges per person: ${String(this.state.deal.chargesPerPerson)[0]},{String(this.state.deal.chargesPerPerson).substring(1)}.00</h4>
                                            <form onSubmit={this.handleSubmit} className="text-left">
                                                <div className="form-group">
                                                    <label htmlFor="noOfPersons">Number of Travelers:</label>
                                                    <input
                                                        type="number"
                                                        id="noOfPersons"
                                                        className="form-control"
                                                        name="noOfPersons"
                                                        value={this.state.bookingForm.noOfPersons}
                                                        onChange={this.handleChange}
                                                    />
                                                    {this.state.bookingFormErrorMessage.noOfPersons ?
                                                        <span className="text-danger">{this.state.bookingFormErrorMessage.noOfPersons}</span>
                                                        : null}
                                                </div>
                                                <div className="form-group">
                                                    <label htmlFor="date">Trip start Date:</label>
                                                    <input
                                                        type="date"
                                                        id="date"
                                                        className="form-control"
                                                        name="date"
                                                        value={this.state.bookingForm.date}
                                                        onChange={this.handleChange}
                                                    />
                                                    {this.state.bookingFormErrorMessage.date ?
                                                        <span className="text-danger">{this.state.bookingFormErrorMessage.date}</span>
                                                        : null}
                                                </div>
                                                <div className="form-group">
                                                    <label>Include Flights:</label>&nbsp;
                                    <InputSwitch name="flights" id="flights"
                                                        checked={this.state.bookingForm.flights}
                                                        onChange={this.handleChange} />
                                                </div>
                                                <div className="form-group">
                                                    <button id="buttonCalc" className="btn btn-primary" type="submit" disabled={!this.state.bookingFormValid.buttonActive}>Calculate Charges</button>&nbsp;
                                </div>
                                            </form>
                                            {!this.state.totalCharges ?
                                                (
                                                    <React.Fragment><div className="text-left">**Charges Exclude flight charges.</div><br /></React.Fragment>
                                                )
                                                :
                                                (
                                                    <h4 className="text-success">
                                                        Your trip ends on {this.state.checkOutDate} and
                                        you will pay ${this.state.totalCharges}
                                                    </h4>
                                                )
                                            }
                                            <div className="text-center">
                                                <button className="btn btn-primary" disabled={!this.state.bookingFormValid.buttonActive}  onClick={() => {
                                                    if (sessionStorage.getItem("contactNo")) {
                                                        this.setState({ "booking": true })
                                                    } else {
                                                        alert("Please Login to continue")
                                                        this.setState({retologin:true})
                                                    }
                                                }}>Book</button>
                                                &nbsp; &nbsp; &nbsp;
                                                 <button type="button" className="btn btn-primary" onClick={(e) => this.setState({ showItinerary: false })}>Cancel</button>
                                            </div>
                                        </TabPanel>
                                    </TabView>
                                    </ScrollPanel>
                                </Sidebar>
                            </div >

                        </div>
                    </div>
                }
            </div>

        )
    }
}

export default HotDeals;