import React, { Component } from 'react';
import { Fieldset } from 'primereact/fieldset';
import { InputSwitch } from 'primereact/inputswitch';
import '../index.css';
import axios from "axios";
import { backendUrlBooking } from '../BackendURL';
import {Link} from "react-router-dom";
import {Redirect } from "react-router-dom";
import { ProgressSpinner } from 'primereact/progressspinner';
import hotdeals from './hotdeals'
import Login from '../components/login';


class booking extends Component {
    constructor(props) {
        super(props);
        this.state = {
            bookingForm: {
                noOfPersons: 1,
                date: "",
                flights: false
            },
            bookingFormErrorMessage: {
                noOfPersons: "",
                date: ""
            },
            bookingFormValid: {
                noOfPersons: false,
                date: false,
                buttonActive: false
            },
            errorMessage: "",
            toggleable: false,
            destinationId: this.props.match.params.destinationId,
            destDeatails: {},
            about: "",
            packageinclusion: [],
            itineraryfirst: "",
            iterlast: "",
            iterrest: [],
            index: "",
            name: "",
            panelCollapsed: true,
            noOfNights: 0,
            flightCharges: 0,
            chargesPerPerson: 0,
            checkOutDate: "",
            totalCharges: 0,
            show: true,
            successmessage: "",
            checkInDate: "",
            backto:false,
            imageUrl:"",
            retologin:false
        }
    }
    calculateCharges = () => {
        this.setState({ totalCharges: 0 });
        let oneDay = 24 * 60 * 60 * 1000;
        let checkInDate = new Date(this.state.bookingForm.date);
        let checkInDateinMs = Math.round(Math.abs((checkInDate.getTime())));
        let finalCheckInDate = new Date(checkInDateinMs);
        let checkOutDateinMs = Math.round(Math.abs((checkInDate.getTime() + (this.state.noOfNights) * oneDay)));
        let finalCheckOutDate = new Date(checkOutDateinMs);
        console.log(this.state.bookingForm.noOfPersons)
        this.setState({ checkInDate: finalCheckInDate.toDateString() });
        this.setState({ checkOutDate: finalCheckOutDate.toDateString() });
        if(this.state.bookingForm.flights) {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.chargesPerPerson + this.state.flightCharges;
            this.setState({ totalCharges: totalCost });
        } else {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.chargesPerPerson;
            this.setState({ totalCharges: totalCost });
        }
    }
    componentDidMount = () => {
        axios.get(backendUrlBooking + '/getDetails/' + this.state.destinationId)
            .then(response => {
                console.log(response)
                this.setState({
                    bookingForm: {  flights:this.props.location.state.flights,noOfPersons: this.props.location.state.noOfPersons, date: this.props.location.state.date },
                    about: response.data.details.about,
                    packageinclusion: response.data.details.itinerary.packageInclusions,
                    itineraryfirst: response.data.details.itinerary.dayWiseDetails.firstDay,
                    iterlast: response.data.details.itinerary.dayWiseDetails.lastDay,
                    iterrest: response.data.details.itinerary.dayWiseDetails.restDaysSightSeeing,
                    name: response.data.name,
                    noOfNights: response.data.noOfNights,
                    flightCharges: response.data.flightCharges,
                    chargesPerPerson: response.data.chargesPerPerson,
                    show:false,
                    imageUrl:response.data.imageUrl
                }); 
                this.calculateCharges();

            }).catch(error => {
                this.setState({ errorMessage: error.response.data.message, destDeatails: {} })
            })
           
    }
    displayPackageHighlights = () => {
        let packageHighLightsArray = [];
        let firstElement = (
            <div key={0}>
                {/* <h3>Day Wise itinerary</h3> */}
                <h5>Day 1</h5>
                <div>{this.state.itineraryfirst}</div>
            </div>
        );
        packageHighLightsArray.push(firstElement);
        this.state.iterrest.map((packageHighlight, index) => {
            let element = (
                <div key={packageHighlight}>
                    <h5>Day {this.state.iterrest.indexOf(packageHighlight) + 2}</h5>
                    <div>{packageHighlight}</div>
                </div>
            );
            return packageHighLightsArray.push(element)
        });
        let lastElement = (
            <div key={666}>
                <h5>Day {this.state.iterrest.length + 2}</h5>
                {this.state.iterlast}
                <div className="text-danger">
                    **This itinerary is just a suggestion, itinerary can be modified as per requirement. <a
                        href="#contact-us">Contact us</a> for more details.
                        </div>
            </div>
        );
        packageHighLightsArray.push(lastElement);
        return packageHighLightsArray;
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.calculateCharges();
        let form = {
            noOfPersons: this.state.bookingForm.noOfPersons,
            checkInDate: this.state.bookingForm.date,
            checkOutDate: this.state.checkOutDate,
            destinationName: this.state.name,
            totalCharges: this.state.totalCharges,
            imageUrl:this.state.imageUrl
        }
        axios.post(backendUrlBooking + '/' + sessionStorage.getItem("userId") + '/' + this.state.destinationId, form)
            .then((response) => {
                this.setState({ successmessage: response.data.message, errorMessage: "",show:false })
            }).catch(error => {
                this.setState({ errorMessage: error.response.data.message, successmessage: "",show:false })
            })
    }

    handleChange = (event) => {
        const target = event.target;
        const name = target.name;
        if (target.checked) {
            var value = target.checked;
            // console.log("i am here")
        } else {
            value = target.value;
        }
        const { bookingForm } = this.state;
        this.setState({
            bookingForm: { ...bookingForm, [name]: value }},()=>{
                this.validateField(name, value);
                this.calculateCharges();
            })
    }


    validateField = (fieldname, value) => {
        let fieldValidationErrors = this.state.bookingFormErrorMessage;
        let formValid = this.state.bookingFormValid;
        switch (fieldname) {
            case "noOfPersons":
                if (value === "") {
                    fieldValidationErrors.noOfPersons = "This field can't be empty!";
                    formValid.noOfPersons = false;
                } else if (value < 1 || value > 5) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be less than 5!";
                    formValid.noOfPersons = false;
                } else if (value > 5) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be more than 5.";
                    formValid.noOfPersons = false;
                } else {
                    fieldValidationErrors.noOfPersons = "";
                    formValid.noOfPersons = true;
                }
                break;
            case "date":
                if (value === "") {
                    fieldValidationErrors.date = "This field can't be empty!";
                    formValid.date = false;
                } else {
                    let checkInDate = new Date(value);
                    let today = new Date();
                    if (today.getTime() > checkInDate.getTime()) {
                        fieldValidationErrors.date = "Check-in date cannot be a past date!";
                        formValid.date = false;
                    } else {
                        fieldValidationErrors.date = "";
                        formValid.date = true;
                    }
                }
                break;
            default:
                break;
        }
    }
    handlebakc=()=>{
       this.setState({backto:true})
    }
    render() {
        return (
            <div>
                {this.state.backto? <Redirect to={"/packages"} Component={hotdeals}></Redirect>:null}
                {this.state.retologin? <Redirect to={"/login"} Component={Login}></Redirect>:null}
                {this.state.show ? (
                    <div id="details" className="details-section">
                        <div className="text-center">
                            <ProgressSpinner></ProgressSpinner>
                        </div>
                    </div>) :
                    <div>
                        <br />
                        <br />
                        {(this.state.successmessage.length > 0) ? <div className="container text-center">
                            <h2>Booking Confirmed!!</h2>
                            <br/>
                            <h2 className="text-success">{this.state.successmessage}</h2>
                            <br/>
                             <h4>
                                <div>Trip starts on : {this.state.checkInDate}</div>
                                <div>Trip ends on :{this.state.checkOutDate}</div>
                            </h4>
                            <br/>
                            <Link to="/viewBookings" className="text-center"> <h4>Click here to view your Bookings</h4>
                            </Link><br /><br /></div> :
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-7">
                                        <div className="text-left">
                                            <h2 className="bold text-info">{this.state.name}</h2>
                                            <div onToggle={(e) => this.setState({ panelCollapsed: e.value })}>
                                                <Fieldset legend="Overview" toggleable={true} collapsed={this.state.panelCollapsed}>
                                                    <p>{this.state.about}</p>
                                                </Fieldset>
                                                <Fieldset legend="Package Inclusion" toggleable={true} collapsed={this.state.panelCollapsed}>
                                                    <ul>
                                                        {this.state.packageinclusion.map((pack) => { return (<li key={pack}>{pack}</li>) })}
                                                    </ul>
                                                </Fieldset>
                                                <Fieldset legend="Itinerary" toggleable={true} collapsed={this.state.panelCollapsed}>
                                                    <ul>
                                                        {this.displayPackageHighlights()}
                                                    </ul>
                                                </Fieldset>

                                            </div>
                                            <br />
                                        </div>
                                    </div>
                                    <div className="col-md-5 ">
                                        <div className="card container">
                                            <form onSubmit={this.handleSubmit} className="text-left">
                                                <br />
                                                <div className="form-group">
                                                    <label htmlFor="noOfPersons">Number of Travelers:</label>
                                                    <input
                                                        type="number"
                                                        id="noOfPersons"
                                                        className="form-control inputline"
                                                        name="noOfPersons"
                                                        value={this.state.bookingForm.noOfPersons}
                                                        onChange={this.handleChange}
                                                    />
                                                    {this.state.bookingFormErrorMessage.noOfPersons ?
                                                        <span className="text-danger">{this.state.bookingFormErrorMessage.noOfPersons}</span>
                                                        : null}
                                                </div>
                                                <div className="form-group">
                                                    <label htmlFor="date">Trip start Date:</label>
                                                    <input
                                                        type="date"
                                                        id="date"
                                                        className="form-control inputline"
                                                        name="date"
                                                        value={this.state.bookingForm.date}
                                                        onChange={this.handleChange}
                                                    />
                                                    {this.state.bookingFormErrorMessage.date ?
                                                        <span className="text-danger">{this.state.bookingFormErrorMessage.date}</span>
                                                        : null}
                                                </div>
                                                <div className="form-group">
                                                    <label>Include Flights:</label>&nbsp;
                                    <InputSwitch name="flights" id="flights"
                                                        checked={this.state.bookingForm.flights}
                                                        onChange={this.handleChange} />
                                                </div>
                                                Your trip ends on : {this.state.checkOutDate}
                                                <h4 className="form-inline">
                                                    You Pay : ${this.state.totalCharges}
                                                </h4>
                                                <br />
                                                <div className="form-group">
                                                    <button type="submit" className="btn btn-primary" onClick={() => {
                                                        if (sessionStorage.getItem("contactNo")) {
                                                            this.setState({ "booking": true })
                                                        } else {
                                                            alert("Please Login to continue")
                                                            this.setState({retologin:true})
                                                        }
                                                    }}>Confirm Booking</button>`
                                                    <button type="button" className="btn btn-primary" onClick={this.handlebakc}>Go Back</button>
                                                </div>
                                                <br />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                    </div>
                }
            </div>
        );
    }
}

export default booking;